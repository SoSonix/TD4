<?php

namespace Cinema;

class ModelException extends \Exception
{
}
